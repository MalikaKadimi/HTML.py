function saveregformdata() {
    alert(document.getElementById("regformdata").value);
    alert(document.getElementById("regformdata1").value);
    alert(document.getElementById("regformdata2").value);
    alert(document.getElementById("regformdata3").value);
    alert(document.getElementById("regformdata4").value);
    alert(document.getElementById("regformdata5").value);
    alert(document.getElementById("regformdata6").value);
    alert(document.getElementById("regformdata7").value);
    alert(document.getElementById("regformdata8").value);
    alert(document.getElementById("regformdata9").value);
}
